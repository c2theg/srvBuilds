/*
 * module to include the ifTable implementation modules
 *
 */

config_require(if-mib/ifTable)

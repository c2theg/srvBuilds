#ifndef SCALAR_INT_H
#define SCALAR_INT_H

#ifdef __cplusplus
extern "C" {
#endif

void            init_scalar_int(void);

#ifdef __cplusplus
}
#endif

#endif                          /* SCALAR_INT_H */

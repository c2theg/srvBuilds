#ifndef SNMPTSMSTATS_H
#define SNMPTSMSTATS_H

config_require(tsm-mib/snmpTsmStats/snmpTsmStats)

#endif /* SNMPTSMSTATS_H */
